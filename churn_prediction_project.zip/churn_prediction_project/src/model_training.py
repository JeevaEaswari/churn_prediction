import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, classification_report
import pickle
import os

# Load the dataset
data_path = r'C:\Users\HP\OneDrive\Desktop\churn_prediction_project\data\churn_data.csv'
df = pd.read_csv(data_path)

# Define target and features
target = 'churned'
features = [
    'course_id', 'days_since_login', 'total_logins',
    'videos_watched', 'assignments_submitted',
    'quiz_score_avg', 'forum_posts', 'course_progress'
]

# Check for missing columns
missing_features = [f for f in features if f not in df.columns]
if missing_features:
    raise KeyError(f"Missing features: {missing_features}")
if target not in df.columns:
    raise KeyError(f"Target column '{target}' not found!")

# Label Encode 'course_id'
le = LabelEncoder()
df['course_id'] = le.fit_transform(df['course_id'])

# Feature matrix and target vector
X = df[features]
y = df[target]

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train model
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Evaluate
y_pred = model.predict(X_test)

print("Accuracy:", accuracy_score(y_test, y_pred))
print("Classification Report:\n", classification_report(y_test, y_pred))

# Save model
model_dir = r'C:\Users\HP\OneDrive\Desktop\churn_prediction_project\models'
os.makedirs(model_dir, exist_ok=True)
model_path = os.path.join(model_dir, 'churn_model.pkl')
with open(model_path, 'wb') as f:
    pickle.dump(model, f)

# Save the label encoder too
le_path = os.path.join(model_dir, 'label_encoder.pkl')
with open(le_path, 'wb') as f:
    pickle.dump(le, f)

print(f" Model saved to: {model_path}")
print(f"LabelEncoder saved to: {le_path}")
