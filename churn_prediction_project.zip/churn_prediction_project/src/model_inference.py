import joblib
import pandas as pd

# Load the saved model
model_filename = r'C:\Users\HP\OneDrive\Desktop\churn_prediction_project\models\churn_prediction_model.pkl'
model = joblib.load(model_filename)

# Load new customer data (example: data from a new customer or batch of customers)
# Ensure this new data is preprocessed in the same way as the training data
new_data = pd.read_csv(r'C:\Users\HP\OneDrive\Desktop\churn_prediction_project\data\new_customer_data.csv')

# Preprocess the new data (e.g., Label Encoding if needed)
# new_data = preprocess_new_data(new_data)

# Make predictions
predictions = model.predict(new_data)

# Output predictions
print("Predictions for new data:")
print(predictions)
