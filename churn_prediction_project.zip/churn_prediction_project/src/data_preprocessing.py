import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

# Load dataset
data = pd.read_csv(r'C:\Users\HP\OneDrive\Desktop\churn_prediction_project\data\churn_data.csv')

# Check for missing values
print("Missing values in each column:")
print(data.isnull().sum())

# Identify categorical columns
categorical_columns = data.select_dtypes(include=['object']).columns

# Apply Label Encoding to categorical columns
label_encoder = LabelEncoder()
for col in categorical_columns:
    data[col] = label_encoder.fit_transform(data[col])

# Split into features (X) and target (y)
X = data.drop(columns=['churned', 'student_id'])
y = data['churned']

# Split data into training and testing sets (80-20 split)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Save processed data
X_train.to_csv(r'C:\Users\HP\OneDrive\Desktop\churn_prediction_project\data\X_train.csv', index=False)
y_train.to_csv(r'C:\Users\HP\OneDrive\Desktop\churn_prediction_project\data\y_train.csv', index=False)
X_test.to_csv(r'C:\Users\HP\OneDrive\Desktop\churn_prediction_project\data\X_test.csv', index=False)
y_test.to_csv(r'C:\Users\HP\OneDrive\Desktop\churn_prediction_project\data\y_test.csv', index=False)

print('Data Preprocessing Completed and Files Saved')
