import streamlit as st
import pandas as pd
import pickle
import matplotlib.pyplot as plt 
import seaborn as sns


# File Paths 
model_path = r'C:\Users\HP\OneDrive\Desktop\churn_prediction_project\models\churn_model.pkl'
encoder_path = r'C:\Users\HP\OneDrive\Desktop\churn_prediction_project\models\label_encoder.pkl'

# Load the trained model 
with open(model_path, 'rb') as file:
    model = pickle.load(file)

#  Load the Label Encoder 
with open(encoder_path, 'rb') as f:
    le = pickle.load(f)

#  Streamlit Page Setup 
st.set_page_config(page_title="Online Learning Churn Predictor", layout="centered")
st.markdown("<h1 style='text-align: center; color: #F7C948;'>🎓 Online Learning Churn Prediction</h1>", unsafe_allow_html=True)
st.markdown("<p style='text-align: center; color: #CCCCCC;'>Predict if a learner will drop out based on their course activity</p>", unsafe_allow_html=True)
st.markdown("---")

#  Expected Features
expected_features = [
    'course_id', 'days_since_login', 'total_logins',
    'videos_watched', 'assignments_submitted',
    'quiz_score_avg', 'forum_posts', 'course_progress'
]

#  File Uploader 
uploaded_file = st.file_uploader("Upload CSV", type="csv")

if uploaded_file is not None:
    try:
        new_data = pd.read_csv(uploaded_file)

        st.subheader("Uploaded Data")
        st.write(new_data)

        # Check if all required columns are present
        if not all(col in new_data.columns for col in expected_features):
            missing = list(set(expected_features) - set(new_data.columns))
            st.error(f" Missing required columns: {missing}")
        else:
            # Encode course_id
            new_data['course_id'] = le.transform(new_data['course_id'])

            # Prepare input
            input_data = new_data[expected_features]

            #  Make Predictions
            predictions = model.predict(input_data)

            # Custom friendly message
            messages = [
                'This customer is likely to give up the course.'
                if pred == 1 else
                'This customer is likely to continue.'
                for pred in predictions
            ]

            # Add results
            new_data['Churn_Prediction'] = predictions
            new_data['Message'] = messages
            
            # Count predictions
            churn_count = sum(predictions)
            non_churn_count = len(predictions) - churn_count

#  Visual Summary
            st.subheader("Visual Summary")

# Pie Chart
            fig1, ax1 = plt.subplots()
            ax1.pie([non_churn_count, churn_count], labels=['Likely to Continue', 'Likely to Dropout'],
        colors=['#28a745', '#dc3545'], autopct='%1.1f%%', startangle=90, textprops={'color': "white"})
            ax1.axis('equal')
            st.pyplot(fig1)

# Bar Chart
            fig2, ax2 = plt.subplots()
            sns.barplot(x=['Likely to Continue', 'Likely to Dropout'],
            y=[non_churn_count, churn_count],
            palette=['#28a745', '#dc3545'], ax=ax2)
            ax2.set_ylabel("Number of Learners")
            ax2.set_title("Churn Distribution")
            st.pyplot(fig2)

            st.subheader(" Prediction Results")
            st.write(new_data[['Churn_Prediction', 'Message']])

            st.download_button("Download Predictions",
                               new_data.to_csv(index=False),
                               file_name='churn_predictions.csv',
                               mime='text/csv')

    except Exception as e:
        st.error(f" Error: {e}")
